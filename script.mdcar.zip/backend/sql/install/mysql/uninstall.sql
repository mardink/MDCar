DROP TABLE IF EXISTS `#__mdcar_cars`;
DROP TABLE IF EXISTS `#__mdcar_receipts`;